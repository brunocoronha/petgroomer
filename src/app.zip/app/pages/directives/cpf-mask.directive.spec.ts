import { CpfMaskDirective } from './cpf-mask.directive';

describe('CpfMaskDirective', () => {
  it('should create an instance', () => {
    const directive = new CpfMaskDirective();
    expect(directive).toBeTruthy();
  });
});
