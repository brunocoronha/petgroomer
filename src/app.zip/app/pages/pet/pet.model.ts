export interface Pet {
  id: string;
  nome: string;
  raca: string;
  cor: string;
  porte: string;
  isActive: boolean;
  id_proprietario: string;
}
